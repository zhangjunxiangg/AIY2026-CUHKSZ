#!/usr/bin/env python3
"""Guided eye-to-hand calibration for a fixed Astra RGB-D camera."""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any, Iterable

import cv2
import numpy as np


SCHEMA_VERSION = 1
CAMERA_FRAME = "astra_camera_color_optical_frame"
BASE_FRAME = "base_link"
DEFAULT_MARKER_ID = 0
DEFAULT_MARKER_SIZE_M = 0.060
DEFAULT_MARKER_DICTIONARY = "DICT_4X4_50"
MIN_SAMPLES = 10


def matrix_from_quaternion_xyzw(values: Iterable[float]) -> np.ndarray:
    x, y, z, w = [float(value) for value in values]
    norm = math.sqrt(x * x + y * y + z * z + w * w)
    if norm < 1e-12:
        raise ValueError("zero-length quaternion")
    x, y, z, w = x / norm, y / norm, z / norm, w / norm
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )


def quaternion_xyzw_from_matrix(rotation: np.ndarray) -> list[float]:
    matrix = np.asarray(rotation, dtype=np.float64)
    trace = float(np.trace(matrix))
    if trace > 0.0:
        scale = math.sqrt(trace + 1.0) * 2.0
        w = 0.25 * scale
        x = (matrix[2, 1] - matrix[1, 2]) / scale
        y = (matrix[0, 2] - matrix[2, 0]) / scale
        z = (matrix[1, 0] - matrix[0, 1]) / scale
    else:
        index = int(np.argmax(np.diag(matrix)))
        if index == 0:
            scale = math.sqrt(1.0 + matrix[0, 0] - matrix[1, 1] - matrix[2, 2]) * 2.0
            w = (matrix[2, 1] - matrix[1, 2]) / scale
            x = 0.25 * scale
            y = (matrix[0, 1] + matrix[1, 0]) / scale
            z = (matrix[0, 2] + matrix[2, 0]) / scale
        elif index == 1:
            scale = math.sqrt(1.0 + matrix[1, 1] - matrix[0, 0] - matrix[2, 2]) * 2.0
            w = (matrix[0, 2] - matrix[2, 0]) / scale
            x = (matrix[0, 1] + matrix[1, 0]) / scale
            y = 0.25 * scale
            z = (matrix[1, 2] + matrix[2, 1]) / scale
        else:
            scale = math.sqrt(1.0 + matrix[2, 2] - matrix[0, 0] - matrix[1, 1]) * 2.0
            w = (matrix[1, 0] - matrix[0, 1]) / scale
            x = (matrix[0, 2] + matrix[2, 0]) / scale
            y = (matrix[1, 2] + matrix[2, 1]) / scale
            z = 0.25 * scale
    quaternion = np.array([x, y, z, w], dtype=np.float64)
    quaternion /= np.linalg.norm(quaternion)
    if quaternion[3] < 0.0:
        quaternion *= -1.0
    return [float(value) for value in quaternion]


def transform(rotation: np.ndarray, translation: Iterable[float]) -> np.ndarray:
    result = np.eye(4, dtype=np.float64)
    result[:3, :3] = np.asarray(rotation, dtype=np.float64).reshape(3, 3)
    result[:3, 3] = np.asarray(list(translation), dtype=np.float64).reshape(3)
    return result


def invert_transform(value: np.ndarray) -> np.ndarray:
    result = np.eye(4, dtype=np.float64)
    result[:3, :3] = value[:3, :3].T
    result[:3, 3] = -result[:3, :3].dot(value[:3, 3])
    return result


def rotation_angle_degrees(rotation: np.ndarray) -> float:
    cosine = max(-1.0, min(1.0, (float(np.trace(rotation)) - 1.0) * 0.5))
    return math.degrees(math.acos(cosine))


def average_rotation(rotations: list[np.ndarray]) -> np.ndarray:
    accumulator = sum(rotations, np.zeros((3, 3), dtype=np.float64))
    u, _singular, vt = np.linalg.svd(accumulator)
    result = u.dot(vt)
    if np.linalg.det(result) < 0.0:
        u[:, -1] *= -1.0
        result = u.dot(vt)
    return result


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def sample_transform(sample: dict[str, Any], key: str) -> np.ndarray:
    value = sample[key]
    return transform(value["rotation_matrix"], value["translation_m"])


def load_dataset(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {
            "schema_version": SCHEMA_VERSION,
            "calibration_type": "eye_to_hand",
            "base_frame": BASE_FRAME,
            "camera_frame": CAMERA_FRAME,
            "marker_dictionary": DEFAULT_MARKER_DICTIONARY,
            "marker_id": DEFAULT_MARKER_ID,
            "marker_size_m": DEFAULT_MARKER_SIZE_M,
            "samples": [],
        }
    dataset = read_json(path)
    if dataset.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("unsupported dataset schema")
    return dataset


def marker_dictionary(name: str = DEFAULT_MARKER_DICTIONARY) -> Any:
    dictionaries = {
        "DICT_4X4_50": cv2.aruco.DICT_4X4_50,
        "DICT_APRILTAG_36h11": cv2.aruco.DICT_APRILTAG_36h11,
        "DICT_APRILTAG_36h10": cv2.aruco.DICT_APRILTAG_36h10,
        "DICT_5X5_100": cv2.aruco.DICT_5X5_100,
    }
    if name not in dictionaries:
        raise ValueError("unsupported marker dictionary: %s" % name)
    return cv2.aruco.Dictionary_get(dictionaries[name])


def generate_marker(
    output: Path, marker_id: int, pixels: int, quiet_pixels: int,
    dictionary_name: str = DEFAULT_MARKER_DICTIONARY,
    marker_size_m: float = DEFAULT_MARKER_SIZE_M,
) -> None:
    dictionary = marker_dictionary(dictionary_name)
    marker = cv2.aruco.drawMarker(dictionary, marker_id, pixels)
    image = cv2.copyMakeBorder(
        marker,
        quiet_pixels,
        quiet_pixels,
        quiet_pixels,
        quiet_pixels,
        cv2.BORDER_CONSTANT,
        value=255,
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(output), image):
        raise RuntimeError(f"failed to write marker: {output}")
    print(
        json.dumps(
            {
                "ok": True,
                "marker_id": marker_id,
                "dictionary": dictionary_name,
                "image": str(output),
                "black_square_print_size_mm": marker_size_m * 1000.0,
                "note": "Marker size is the black square edge; the white quiet border is excluded.",
            },
            ensure_ascii=False,
        )
    )


def pose_to_transform(pose: Any) -> np.ndarray:
    rotation = matrix_from_quaternion_xyzw(
        [pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w]
    )
    return transform(rotation, [pose.position.x, pose.position.y, pose.position.z])


def transform_payload(value: np.ndarray) -> dict[str, Any]:
    return {
        "translation_m": [float(item) for item in value[:3, 3]],
        "rotation_matrix": [[float(item) for item in row] for row in value[:3, :3]],
        "quaternion_xyzw": quaternion_xyzw_from_matrix(value[:3, :3]),
    }


def detect_marker_pose(
    frame: np.ndarray,
    camera_matrix: np.ndarray,
    distortion: np.ndarray,
    marker_id: int,
    marker_size_m: float,
    dictionary_name: str,
) -> tuple[np.ndarray, np.ndarray, np.ndarray] | None:
    parameters = cv2.aruco.DetectorParameters_create()
    corners, ids, _rejected = cv2.aruco.detectMarkers(
        frame, marker_dictionary(dictionary_name), parameters=parameters
    )
    if ids is None:
        return None
    flat_ids = ids.flatten().tolist()
    if marker_id not in flat_ids:
        return None
    index = flat_ids.index(marker_id)
    selected = corners[index]
    perimeter = float(cv2.arcLength(selected.astype(np.float32), True))
    if perimeter < 100.0:
        return None
    rvecs, tvecs, _points = cv2.aruco.estimatePoseSingleMarkers(
        [selected], marker_size_m, camera_matrix, distortion
    )
    rotation, _jacobian = cv2.Rodrigues(rvecs[0, 0])
    translation = np.asarray(tvecs[0, 0], dtype=np.float64)
    return rotation, translation, selected


def capture(args: argparse.Namespace) -> int:
    import rospy
    from cv_bridge import CvBridge
    from interfaces.srv import GetRobotPose
    from sensor_msgs.msg import CameraInfo, Image

    dataset_path = Path(args.dataset)
    dataset = load_dataset(dataset_path)
    if dataset["samples"]:
        if int(dataset["marker_id"]) != args.marker_id:
            raise ValueError("marker id differs from the existing dataset")
        if abs(float(dataset["marker_size_m"]) - args.marker_size) > 1e-9:
            raise ValueError("marker size differs from the existing dataset")
        if str(dataset.get("marker_dictionary", DEFAULT_MARKER_DICTIONARY)) != args.dictionary:
            raise ValueError("marker dictionary differs from the existing dataset")
    else:
        dataset["marker_id"] = args.marker_id
        dataset["marker_size_m"] = args.marker_size
        dataset["marker_dictionary"] = args.dictionary

    rospy.init_node("astra_arm_handeye_capture", anonymous=True, disable_signals=True)
    rospy.wait_for_service("/kinematics/get_current_pose", timeout=8.0)
    get_pose = rospy.ServiceProxy("/kinematics/get_current_pose", GetRobotPose)
    bridge = CvBridge()

    before = get_pose()
    if not before.success or not before.solution:
        raise RuntimeError("mechanical arm pose is unavailable")
    base_to_gripper_before = pose_to_transform(before.pose)

    camera_info = rospy.wait_for_message(
        "/astra_camera/rgb/camera_info", CameraInfo, timeout=8.0
    )
    if camera_info.header.frame_id != CAMERA_FRAME:
        raise RuntimeError(f"unexpected camera frame: {camera_info.header.frame_id}")
    camera_matrix = np.asarray(camera_info.K, dtype=np.float64).reshape(3, 3)
    distortion = np.asarray(camera_info.D, dtype=np.float64)
    if camera_matrix[0, 0] <= 1.0 or camera_matrix[1, 1] <= 1.0:
        raise RuntimeError("camera intrinsics are invalid")

    rotations: list[np.ndarray] = []
    translations: list[np.ndarray] = []
    depth_differences: list[float] = []
    last_frame: np.ndarray | None = None
    last_corners: np.ndarray | None = None

    deadline = time.monotonic() + args.timeout
    while len(rotations) < args.frames and time.monotonic() < deadline:
        image_message = rospy.wait_for_message(
            "/astra_camera/rgb/image_raw", Image, timeout=4.0
        )
        frame = bridge.imgmsg_to_cv2(image_message, "bgr8")
        # Keep the latest frame even when detection fails so the caller can
        # inspect framing, occlusion, exposure, or dictionary mismatches.
        last_frame = frame.copy()
        detection = detect_marker_pose(
            frame,
            camera_matrix,
            distortion,
            args.marker_id,
            args.marker_size,
            args.dictionary,
        )
        if detection is None:
            continue
        rotation, translation, corners = detection
        if not 0.15 <= float(translation[2]) <= 2.0:
            continue

        try:
            depth_message = rospy.wait_for_message(
                "/astra_camera/depth/image_raw", Image, timeout=2.0
            )
            depth = np.asarray(bridge.imgmsg_to_cv2(depth_message, "passthrough"))
            center = corners.reshape(-1, 2).mean(axis=0)
            cx, cy = int(round(center[0])), int(round(center[1]))
            roi = depth[max(0, cy - 4):cy + 5, max(0, cx - 4):cx + 5]
            valid = roi[np.isfinite(roi) & (roi > 0)]
            if valid.size:
                depth_m = float(np.median(valid))
                if depth_m > 10.0:
                    depth_m /= 1000.0
                difference = abs(depth_m - float(translation[2]))
                depth_differences.append(difference)
                if difference > 0.08:
                    continue
        except Exception:
            pass

        rotations.append(rotation)
        translations.append(translation)
        last_frame = frame.copy()
        last_corners = corners.copy()

    if len(rotations) < max(5, args.frames // 2):
        if last_frame is not None:
            failed = last_frame.copy()
            cv2.putText(
                failed,
                "NO_VALID_TAG_SAMPLE",
                (12, 32),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 0, 255),
                2,
                cv2.LINE_AA,
            )
            cv2.putText(
                failed,
                "%s id=%d" % (args.dictionary, args.marker_id),
                (12, 62),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (0, 0, 255),
                2,
                cv2.LINE_AA,
            )
            image_path = Path(args.image)
            image_path.parent.mkdir(parents=True, exist_ok=True)
            cv2.imwrite(str(image_path), failed)
        raise RuntimeError(
            f"marker {args.marker_id} was not detected reliably; valid_frames={len(rotations)}"
        )

    after = get_pose()
    if not after.success or not after.solution:
        raise RuntimeError("mechanical arm pose became unavailable")
    base_to_gripper_after = pose_to_transform(after.pose)
    arm_translation_delta = float(
        np.linalg.norm(base_to_gripper_after[:3, 3] - base_to_gripper_before[:3, 3])
    )
    arm_rotation_delta = rotation_angle_degrees(
        base_to_gripper_before[:3, :3].T.dot(base_to_gripper_after[:3, :3])
    )
    if arm_translation_delta > 0.003 or arm_rotation_delta > 1.5:
        if last_frame is not None:
            cv2.imwrite(str(Path(args.image)), last_frame)
        raise RuntimeError(
            "arm moved during capture: translation=%.4fm rotation=%.2fdeg"
            % (arm_translation_delta, arm_rotation_delta)
        )

    base_to_gripper = transform(
        average_rotation(
            [base_to_gripper_before[:3, :3], base_to_gripper_after[:3, :3]]
        ),
        (base_to_gripper_before[:3, 3] + base_to_gripper_after[:3, 3]) * 0.5,
    )
    camera_to_target = transform(
        average_rotation(rotations), np.median(np.asarray(translations), axis=0)
    )

    for previous in dataset["samples"]:
        previous_pose = sample_transform(previous, "base_to_gripper")
        translation_delta = float(
            np.linalg.norm(previous_pose[:3, 3] - base_to_gripper[:3, 3])
        )
        rotation_delta = rotation_angle_degrees(
            previous_pose[:3, :3].T.dot(base_to_gripper[:3, :3])
        )
        if translation_delta < 0.020 and rotation_delta < 7.0:
            if last_frame is not None:
                cv2.imwrite(str(Path(args.image)), last_frame)
            raise RuntimeError(
                "pose is too similar to an existing sample; move at least 2cm or rotate 7deg"
            )

    sample_number = len(dataset["samples"]) + 1
    sample = {
        "index": sample_number,
        "captured_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "base_to_gripper": transform_payload(base_to_gripper),
        "camera_to_target": transform_payload(camera_to_target),
        "valid_frames": len(rotations),
        "marker_translation_std_m": [
            float(value) for value in np.std(np.asarray(translations), axis=0)
        ],
        "median_depth_pnp_difference_m": (
            float(np.median(depth_differences)) if depth_differences else None
        ),
        "arm_motion_during_capture_m": arm_translation_delta,
        "arm_rotation_during_capture_deg": arm_rotation_delta,
    }
    dataset["camera_intrinsics"] = {
        "width": int(camera_info.width),
        "height": int(camera_info.height),
        "distortion_model": camera_info.distortion_model,
        "D": [float(value) for value in camera_info.D],
        "K": [float(value) for value in camera_info.K],
    }
    dataset["samples"].append(sample)
    write_json(dataset_path, dataset)

    if last_frame is not None and last_corners is not None:
        annotated = last_frame.copy()
        cv2.aruco.drawDetectedMarkers(
            annotated,
            [last_corners],
            np.asarray([[args.marker_id]], dtype=np.int32),
        )
        cv2.drawFrameAxes(
            annotated,
            camera_matrix,
            distortion,
            cv2.Rodrigues(camera_to_target[:3, :3])[0],
            camera_to_target[:3, 3],
            args.marker_size * 0.5,
        )
        image_path = Path(args.image)
        image_path.parent.mkdir(parents=True, exist_ok=True)
        cv2.imwrite(str(image_path), annotated)

    print(
        json.dumps(
            {
                "ok": True,
                "sample": sample_number,
                "total_samples": len(dataset["samples"]),
                "minimum_samples": MIN_SAMPLES,
                "camera_to_target_translation_m": sample["camera_to_target"]["translation_m"],
                "base_to_gripper_translation_m": sample["base_to_gripper"]["translation_m"],
                "median_depth_pnp_difference_m": sample["median_depth_pnp_difference_m"],
            },
            ensure_ascii=False,
        )
    )
    return 0


def calibration_methods() -> list[tuple[str, int]]:
    return [
        ("TSAI", cv2.CALIB_HAND_EYE_TSAI),
        ("PARK", cv2.CALIB_HAND_EYE_PARK),
        ("HORAUD", cv2.CALIB_HAND_EYE_HORAUD),
        ("ANDREFF", cv2.CALIB_HAND_EYE_ANDREFF),
        ("DANIILIDIS", cv2.CALIB_HAND_EYE_DANIILIDIS),
    ]


def solve_once(samples: list[dict[str, Any]], method: int) -> np.ndarray:
    base_to_gripper = [sample_transform(item, "base_to_gripper") for item in samples]
    camera_to_target = [sample_transform(item, "camera_to_target") for item in samples]
    base_to_gripper_inverse = [invert_transform(value) for value in base_to_gripper]
    rotation, translation = cv2.calibrateHandEye(
        [value[:3, :3] for value in base_to_gripper_inverse],
        [value[:3, 3].reshape(3, 1) for value in base_to_gripper_inverse],
        [value[:3, :3] for value in camera_to_target],
        [value[:3, 3].reshape(3, 1) for value in camera_to_target],
        method=method,
    )
    result = transform(rotation, np.asarray(translation).reshape(3))
    if not np.all(np.isfinite(result)) or abs(np.linalg.det(result[:3, :3]) - 1.0) > 1e-3:
        raise ValueError("solver returned an invalid transform")
    return result


def residuals(samples: list[dict[str, Any]], base_to_camera: np.ndarray) -> dict[str, Any]:
    implied_gripper_to_target: list[np.ndarray] = []
    for sample in samples:
        base_to_gripper = sample_transform(sample, "base_to_gripper")
        camera_to_target = sample_transform(sample, "camera_to_target")
        implied_gripper_to_target.append(
            invert_transform(base_to_gripper).dot(base_to_camera).dot(camera_to_target)
        )
    mean_translation = np.mean(
        np.asarray([value[:3, 3] for value in implied_gripper_to_target]), axis=0
    )
    mean_rotation = average_rotation([value[:3, :3] for value in implied_gripper_to_target])
    translation_errors = [
        float(np.linalg.norm(value[:3, 3] - mean_translation))
        for value in implied_gripper_to_target
    ]
    rotation_errors = [
        rotation_angle_degrees(mean_rotation.T.dot(value[:3, :3]))
        for value in implied_gripper_to_target
    ]
    return {
        "translation_errors_m": translation_errors,
        "rotation_errors_deg": rotation_errors,
        "translation_rmse_m": float(
            math.sqrt(np.mean(np.square(translation_errors)))
        ),
        "translation_max_m": float(max(translation_errors)),
        "rotation_rmse_deg": float(math.sqrt(np.mean(np.square(rotation_errors)))),
        "rotation_max_deg": float(max(rotation_errors)),
        "gripper_to_target": transform_payload(transform(mean_rotation, mean_translation)),
    }


def solve_samples(samples: list[dict[str, Any]]) -> tuple[str, np.ndarray, dict[str, Any]]:
    candidates: list[tuple[float, str, np.ndarray, dict[str, Any]]] = []
    for name, method in calibration_methods():
        try:
            solution = solve_once(samples, method)
            metrics = residuals(samples, solution)
            score = metrics["translation_rmse_m"] + math.radians(
                metrics["rotation_rmse_deg"]
            ) * 0.05
            candidates.append((score, name, solution, metrics))
        except Exception as exc:
            print(f"SOLVER_{name}=SKIPPED {exc}", file=sys.stderr)
    if not candidates:
        raise RuntimeError("all hand-eye solvers failed")
    _score, name, solution, metrics = min(candidates, key=lambda item: item[0])
    return name, solution, metrics


def pose_diversity(samples: list[dict[str, Any]]) -> tuple[float, float]:
    poses = [sample_transform(item, "base_to_gripper") for item in samples]
    max_translation = 0.0
    max_rotation = 0.0
    for left_index, left in enumerate(poses):
        for right in poses[left_index + 1:]:
            max_translation = max(
                max_translation, float(np.linalg.norm(left[:3, 3] - right[:3, 3]))
            )
            max_rotation = max(
                max_rotation,
                rotation_angle_degrees(left[:3, :3].T.dot(right[:3, :3])),
            )
    return max_translation, max_rotation


def solve(args: argparse.Namespace) -> int:
    dataset = load_dataset(Path(args.dataset))
    samples = list(dataset["samples"])
    if len(samples) < MIN_SAMPLES:
        raise RuntimeError(
            f"need at least {MIN_SAMPLES} samples; current dataset has {len(samples)}"
        )
    translation_span, rotation_span = pose_diversity(samples)
    if translation_span < 0.08:
        raise RuntimeError(
            f"arm pose translation span is too small: {translation_span:.3f}m; need >=0.08m"
        )
    if rotation_span < 20.0:
        raise RuntimeError(
            f"arm pose rotation span is too small: {rotation_span:.1f}deg; need >=20deg"
        )

    method, base_to_camera, metrics = solve_samples(samples)
    translation_errors = np.asarray(metrics["translation_errors_m"])
    rotation_errors = np.asarray(metrics["rotation_errors_deg"])
    translation_median = float(np.median(translation_errors))
    rotation_median = float(np.median(rotation_errors))
    keep = [
        index
        for index, (translation_error, rotation_error) in enumerate(
            zip(translation_errors, rotation_errors)
        )
        if translation_error <= max(0.018, translation_median * 3.0)
        and rotation_error <= max(5.0, rotation_median * 3.0)
    ]
    rejected_indices: list[int] = []
    if len(keep) >= MIN_SAMPLES and len(keep) < len(samples):
        rejected_indices = [
            int(samples[index].get("index", index + 1))
            for index in range(len(samples))
            if index not in keep
        ]
        filtered = [samples[index] for index in keep]
        method, base_to_camera, metrics = solve_samples(filtered)
        samples = filtered

    quality_pass = (
        metrics["translation_rmse_m"] <= 0.012
        and metrics["rotation_rmse_deg"] <= 3.0
    )
    result = {
        "schema_version": SCHEMA_VERSION,
        "calibration_type": "eye_to_hand",
        "parent_frame": BASE_FRAME,
        "child_frame": CAMERA_FRAME,
        "base_to_camera": transform_payload(base_to_camera),
        "solver": method,
        "sample_count": len(samples),
        "rejected_sample_indices": rejected_indices,
        "pose_translation_span_m": translation_span,
        "pose_rotation_span_deg": rotation_span,
        "residual_translation_rmse_m": metrics["translation_rmse_m"],
        "residual_translation_max_m": metrics["translation_max_m"],
        "residual_rotation_rmse_deg": metrics["rotation_rmse_deg"],
        "residual_rotation_max_deg": metrics["rotation_max_deg"],
        "estimated_gripper_to_marker": metrics["gripper_to_target"],
        "marker_dictionary": dataset["marker_dictionary"],
        "marker_id": dataset["marker_id"],
        "marker_size_m": dataset["marker_size_m"],
        "quality": "PASS" if quality_pass else "REVIEW",
        "quality_limits": {
            "translation_rmse_m": 0.012,
            "rotation_rmse_deg": 3.0,
        },
        "solved_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
    }
    write_json(Path(args.output), result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if quality_pass else 2


def status(args: argparse.Namespace) -> int:
    dataset = load_dataset(Path(args.dataset))
    samples = dataset["samples"]
    translation_span, rotation_span = pose_diversity(samples) if len(samples) > 1 else (0.0, 0.0)
    print(
        json.dumps(
            {
                "ok": True,
                "sample_count": len(samples),
                "minimum_samples": MIN_SAMPLES,
                "translation_span_m": translation_span,
                "rotation_span_deg": rotation_span,
                "ready_to_solve": (
                    len(samples) >= MIN_SAMPLES
                    and translation_span >= 0.08
                    and rotation_span >= 20.0
                ),
            },
            ensure_ascii=False,
        )
    )
    return 0


def transform_point(args: argparse.Namespace) -> int:
    calibration = read_json(Path(args.calibration))
    base_to_camera = transform(
        calibration["base_to_camera"]["rotation_matrix"],
        calibration["base_to_camera"]["translation_m"],
    )
    camera_point = np.array([args.x, args.y, args.z, 1.0], dtype=np.float64)
    base_point = base_to_camera.dot(camera_point)
    print(
        json.dumps(
            {
                "ok": True,
                "camera_frame": calibration["child_frame"],
                "base_frame": calibration["parent_frame"],
                "camera_point_m": [args.x, args.y, args.z],
                "base_point_m": [float(value) for value in base_point[:3]],
            },
            ensure_ascii=False,
        )
    )
    return 0


def random_transform(rng: np.random.RandomState, translation_scale: float) -> np.ndarray:
    axis = rng.normal(size=3)
    axis /= np.linalg.norm(axis)
    angle = rng.uniform(-1.0, 1.0)
    rotation, _jacobian = cv2.Rodrigues(axis * angle)
    translation = rng.uniform(-translation_scale, translation_scale, size=3)
    return transform(rotation, translation)


def self_test(_args: argparse.Namespace) -> int:
    rng = np.random.RandomState(41)
    expected_base_to_camera = random_transform(rng, 0.4)
    expected_gripper_to_target = random_transform(rng, 0.08)
    samples: list[dict[str, Any]] = []
    for index in range(18):
        base_to_gripper = random_transform(rng, 0.25)
        camera_to_target = (
            invert_transform(expected_base_to_camera)
            .dot(base_to_gripper)
            .dot(expected_gripper_to_target)
        )
        samples.append(
            {
                "index": index + 1,
                "base_to_gripper": transform_payload(base_to_gripper),
                "camera_to_target": transform_payload(camera_to_target),
            }
        )
    method, solved, metrics = solve_samples(samples)
    translation_error = float(
        np.linalg.norm(solved[:3, 3] - expected_base_to_camera[:3, 3])
    )
    rotation_error = rotation_angle_degrees(
        solved[:3, :3].T.dot(expected_base_to_camera[:3, :3])
    )
    passed = translation_error < 1e-5 and rotation_error < 1e-3
    print(
        json.dumps(
            {
                "ok": passed,
                "method": method,
                "translation_error_m": translation_error,
                "rotation_error_deg": rotation_error,
                "residual_translation_rmse_m": metrics["translation_rmse_m"],
                "residual_rotation_rmse_deg": metrics["rotation_rmse_deg"],
            },
            ensure_ascii=False,
        )
    )
    return 0 if passed else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    marker_parser = subparsers.add_parser("marker")
    marker_parser.add_argument("--output", required=True)
    marker_parser.add_argument("--marker-id", type=int, default=DEFAULT_MARKER_ID)
    marker_parser.add_argument("--dictionary", default=DEFAULT_MARKER_DICTIONARY)
    marker_parser.add_argument("--marker-size", type=float, default=DEFAULT_MARKER_SIZE_M)
    marker_parser.add_argument("--pixels", type=int, default=1200)
    marker_parser.add_argument("--quiet-pixels", type=int, default=200)
    marker_parser.set_defaults(handler=lambda args: (generate_marker(
        Path(args.output), args.marker_id, args.pixels, args.quiet_pixels,
        args.dictionary, args.marker_size
    ) or 0))

    capture_parser = subparsers.add_parser("capture")
    capture_parser.add_argument("--dataset", required=True)
    capture_parser.add_argument("--image", required=True)
    capture_parser.add_argument("--marker-id", type=int, default=DEFAULT_MARKER_ID)
    capture_parser.add_argument("--dictionary", default=DEFAULT_MARKER_DICTIONARY)
    capture_parser.add_argument("--marker-size", type=float, default=DEFAULT_MARKER_SIZE_M)
    capture_parser.add_argument("--frames", type=int, default=15)
    capture_parser.add_argument("--timeout", type=float, default=18.0)
    capture_parser.set_defaults(handler=capture)

    solve_parser = subparsers.add_parser("solve")
    solve_parser.add_argument("--dataset", required=True)
    solve_parser.add_argument("--output", required=True)
    solve_parser.set_defaults(handler=solve)

    status_parser = subparsers.add_parser("status")
    status_parser.add_argument("--dataset", required=True)
    status_parser.set_defaults(handler=status)

    transform_parser = subparsers.add_parser("transform")
    transform_parser.add_argument("--calibration", required=True)
    transform_parser.add_argument("--x", type=float, required=True)
    transform_parser.add_argument("--y", type=float, required=True)
    transform_parser.add_argument("--z", type=float, required=True)
    transform_parser.set_defaults(handler=transform_point)

    self_test_parser = subparsers.add_parser("self-test")
    self_test_parser.set_defaults(handler=self_test)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        return int(args.handler(args))
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        return 1


if __name__ == "__main__":
    sys.exit(main())
